<?php
require '../_base.php';

auth('member');

$order_id = req('id');
$user_id = $_users->id;

$stm = $_db->prepare("SELECT * FROM orders WHERE order_id = ? AND user_id = ? AND status = 'Paid'");
$stm->execute([$order_id, $user_id]);
$order = $stm->fetch();

if ($order) {
    $_db->beginTransaction();

    try {
        // get all quantity and prodcut for this order
        $stm_items = $_db->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
        $stm_items->execute([$order_id]);
        $items = $stm_items->fetchAll();


        $stm_update_stock = $_db->prepare("UPDATE products SET stock = stock + ? WHERE product_id = ?");
        foreach ($items as $item) {
            $stm_update_stock->execute([$item->quantity, $item->product_id]);
        }


        $stm_cancel = $_db->prepare("UPDATE orders SET status = 'Cancelled' WHERE order_id = ?");
        $stm_cancel->execute([$order_id]);
        $_db->commit();
        temp('info', 'Order cancelled and stock restored.');
    } catch (Exception $e) {
        $_db->rollBack();
        temp('info', 'System error: Could not cancel order.');
    }
} else {
    temp('info', 'Order cannot be cancelled.');
}


redirect('order_history.php');