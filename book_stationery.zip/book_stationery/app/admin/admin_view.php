<?php
require '../_base.php';
auth('admin');

// Handle Deletion of a review
if (isset($_GET['delete_id'])) {
    $stm = $_db->prepare("DELETE FROM reviews WHERE review_id = ?");
    $stm->execute([$_GET['delete_id']]);
    temp('info', 'Review deleted.');
    redirect('admin_view.php');
}

// Fetch all views
$stm = $_db->query("SELECT * FROM reviews ORDER BY created_at DESC");
$all_reviews = $stm->fetchAll();

$_title = 'Manage Reviews';
require '../_head.php';
?>

<h2>All Product Reviews</h2>

<table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: left;">
    <tr>
        <th>Product ID</th>
        <th>User ID</th>
        <th>Rating</th>
        <th>Comment</th>
        <th>Date</th>
        <th>Action</th>
    </tr>
    <?php foreach ($all_reviews as $rev): ?>
    <tr>
        <td><?= htmlspecialchars($rev->product_id) ?></td>
        <td><?= htmlspecialchars($rev->user_id) ?></td>
        <td style="color: gold;"><?= str_repeat('★', $rev->rating) ?></td>
        <td><?= htmlspecialchars($rev->comment) ?></td>
        <td><?= $rev->created_at ?></td>
        <td>
            <a href="?delete_id=<?= $rev->review_id ?>" onclick="return confirm('Delete this review?')" style="color: red;">Delete</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php require '../_foot.php'; ?>