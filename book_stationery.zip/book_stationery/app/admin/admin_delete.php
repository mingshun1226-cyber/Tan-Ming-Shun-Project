<?php
require '../_base.php';

auth('admin');

$id = req('id');

// Prevent an admin from deleting themselves
if ($id == $_users->id) {
    die("You cannot delete your own account!");
}
if ($id) {
    // delete request records where this admin is the applicant
    $stm = $_db->prepare("DELETE FROM admin_request WHERE user_id = ?");
    $stm->execute([$id]);

    // delete request records where this admin is the approver
    $stm = $_db->prepare("DELETE FROM admin_request WHERE admin_id = ?");
    $stm->execute([$id]);

    // then delete the admin user
    $stm = $_db->prepare("DELETE FROM users WHERE id = ? ");
    $stm->execute([$id]);

    temp('info', 'Admin deleted successfully.');
    redirect('/admin/admin_list.php');
}
  
redirect('admin_list.php');