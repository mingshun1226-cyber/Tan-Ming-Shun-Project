<?php
require '../_base.php';


auth('admin');

// Check if the user has typed something into the search bar
$search = trim($_GET['search'] ?? '');

if ($search) {

    $stm = $_db->prepare("SELECT * FROM users WHERE (id LIKE ? OR name LIKE ? OR email LIKE ?) ORDER BY id DESC");
    $stm->execute(["%$search%", "%$search%", "%$search%"]);
    $users = $stm->fetchAll();
} else {
  
    $stm = $_db->query("SELECT * FROM users ORDER BY id DESC");
    $users = $stm->fetchAll();
}

$_title = 'User Maintenance';
require '../_head.php';
?>

<style>
   
    .admin-page { background: #f5f5f5; border-radius: 12px; padding: 24px; }
    .admin-hero { background: linear-gradient(135deg, #0058a3, #0078d7); color: white; border-radius: 14px; padding: 24px 28px; margin-bottom: 20px; box-shadow: 0 8px 20px rgba(0, 88, 163, 0.18); }
    .admin-hero h2 { margin: 0 0 8px; font-size: 28px; font-weight: 800; }
    .admin-hero p { margin: 0; font-size: 14px; opacity: 0.95; }
    .admin-toolbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; margin-bottom: 20px; background: #fff; padding: 18px; border-radius: 12px; box-shadow: 0 4px 14px rgba(0,0,0,0.06); }
    .toolbar-left, .toolbar-right { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    
    .admin-btn { display: inline-block; text-decoration: none; border: none; border-radius: 8px; padding: 10px 16px; font-size: 14px; font-weight: 700; cursor: pointer; transition: 0.2s ease; }
    .admin-btn:hover { transform: translateY(-1px); opacity: 0.95; }
    .btn-add { background: #ffcc00; color: #111; }
    .btn-export { background: #7c3aed; color: white; }
    .btn-search { background: #0058a3; color: white; }
    .btn-clear { background: #cf182a; color: white; }
    
    .search-form { display: flex; gap: 8px; flex-wrap: wrap; }
    .search-form input { padding: 10px 14px; width: 260px; border: 1px solid #ccc; border-radius: 8px; font-size: 14px; outline: none; background: #fafafa; }
    .search-form input:focus { border-color: #0058a3; background: #fff; box-shadow: 0 0 0 3px rgba(0, 88, 163, 0.12); }
    
    .admin-table-card { background: white; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 14px rgba(0,0,0,0.06); }
    .admin-table-header { padding: 18px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
    .admin-table-header h3 { margin: 0; font-size: 18px; color: #111; }
    .admin-table-header span { font-size: 13px; color: #666; background: #f3f4f6; padding: 6px 10px; border-radius: 999px; }
    .table-wrap { overflow-x: auto; }
    .admin-table { width: 100%; border-collapse: collapse; min-width: 700px; }
    .admin-table thead { background: #f8f8f8; }
    .admin-table th, .admin-table td { padding: 15px 18px; text-align: left; border-bottom: 1px solid #eee; font-size: 14px; }
    .admin-table th { color: #333; font-weight: 700; }
    .admin-table tbody tr:hover { background: #fcfcfc; }
    
    .user-id { font-weight: 700; color: #0058a3; }
    .user-name { font-weight: 600; color: #111; }
    .user-email { color: #666; }
    
    .role-badge { padding: 4px 8px; border-radius: 4px; font-size: 0.85em; font-weight: bold; }
    .role-admin { background: #ffe4e6; color: #e11d48; }
    .role-member { background: #dcfce7; color: #166534; }

    .action-btns { display: flex; gap: 6px; }
    .view-btn { background: #10b981; color: white; border: none; padding: 7px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .view-btn:hover { background: #059669; }
    .delete-btn { background: #cf182a; color: white; border: none; padding: 7px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .delete-btn:hover { background: #b91524; }
    .current-user { color: #888; font-style: italic; font-weight: 600; }
    .empty-state { text-align: center; padding: 40px 20px; color: #666; }
    
    @media (max-width: 768px) {
        .search-form input { width: 100%; }
        .toolbar-left, .toolbar-right, .search-form { width: 100%; }
    }
</style>

<div class="admin-page">
    <div class="admin-hero">
        <h2>User Maintenance</h2>
        <p>Manage all administrators and members, search quickly, and maintain system access.</p>
    </div>

    <div class="admin-toolbar">
        <div class="toolbar-left">
            <a href="admin_add.php" class="admin-btn btn-add">+ Add New Admin</a>
            <a href="admin_export_users.php" class="admin-btn btn-export">📥 Export Users (CSV)</a>
        </div>

        <div class="toolbar-right">
            <form method="get" action="" class="search-form">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search ID, Name, or Email...">
                <button type="submit" class="admin-btn btn-search">Search</button>
                <?php if ($search): ?>
                    <a href="user_list.php" class="admin-btn btn-clear">Clear</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="admin-table-card">
        <div class="admin-table-header">
            <h3>All Registered Users</h3>
            <span>Total: <?= count($users) ?> record(s)</span>
        </div>

        <div class="table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th style="width: 180px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($users): ?>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td class="user-id"><?= htmlspecialchars($u->id) ?></td>
                                <td class="user-name"><?= htmlspecialchars($u->name) ?></td>
                                <td class="user-email"><?= htmlspecialchars($u->email) ?></td>
                                <td>
                                    <?php if ($u->role === 'admin'): ?>
                                        <span class="role-badge role-admin">Admin</span>
                                    <?php else: ?>
                                        <span class="role-badge role-member">Member</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-btns">
                                        <a href="user_detail.php?id=<?= urlencode($u->id) ?>">
                                            <button class="view-btn">View</button>
                                        </a>

                                        <?php if ($u->id !== $_users->id): ?>
                                            <a href="admin_delete.php?id=<?= urlencode($u->id) ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                                <button class="delete-btn">Delete</button>
                                            </a>
                                        <?php else: ?>
                                            <span class="current-user">(You)</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    No users found matching "<b><?= htmlspecialchars($search) ?></b>".
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require '../_foot.php'; ?>