<?php
include '../_base.php';

auth('admin');

$id = get('id');
$action = get('action');

if (!$id || !in_array($action, ['approve', 'reject'])) {
    temp('info', 'Invalid request.');
    redirect('/admin/admin_request_list.php');
}

$stm = $_db->prepare("
    SELECT * 
    FROM admin_request
    WHERE id = ? AND status = 'pending'
");
$stm->execute([$id]);
$r = $stm->fetch();

if (!$r) {
    temp('info', 'Request not found or already processed.');
    redirect('/admin/admin_request_list.php');
}

// approve
if ($action == 'approve') {

    $stm = $_db->prepare("
        UPDATE users
        SET role = 'admin'
        WHERE id = ?
    ");
    $stm->execute([$r->user_id]);

    $stm = $_db->prepare("
        UPDATE admin_request
        SET status = 'approved', admin_id = ?, responded_at = NOW()
        WHERE id = ?
    ");
    $stm->execute([$_users->id, $id]);

    temp('info', 'Admin request approved.');
    redirect('/admin/admin_request_list.php');
}

// reject
if ($action == 'reject') {

    $stm = $_db->prepare("
        UPDATE admin_request
        SET status = 'rejected', admin_id = ?, responded_at = NOW()
        WHERE id = ?
    ");
    $stm->execute([$_users->id, $id]);

    temp('info', 'Admin request rejected.');
    redirect('/admin/admin_request_list.php');
}