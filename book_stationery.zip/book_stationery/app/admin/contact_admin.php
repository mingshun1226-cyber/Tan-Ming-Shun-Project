<?php
require '../_base.php'; 

// array
$admin_email = '4boyslibrary@gmail.com'; 
$admin_name  = 'Admin';

if (is_post()) {
    $sender_name = req('sender_name'); 
    $subject     = req('subject');
    $message     = req('message');

    // Validation
    if (!$sender_name) {
        temp('err', 'Please enter your name.'); 
    } else if (!$subject) {
        temp('err', 'Please enter a subject.');
    } else if (!$message) {
        temp('err', 'Please enter your message.');
    } else {
        // SEND EMAIL LOGIC
        $m = get_mail(); 
        $m->addAddress($admin_email, $admin_name); 
        $m->isHTML(true); 
        
        $m->Subject = "New Contact Message from: $sender_name - $subject";
        
        $m->Body = "
            <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd; border-radius: 8px;'>
                <h3 style='color: #007bff;'>New Contact Request</h3>
                <p><strong>To:</strong> $admin_name</p>
                <p><strong>From:</strong> $sender_name</p> 
                <p><strong>Subject:</strong> $subject</p>
                <hr>
                <p><strong>Message:</strong></p>
                <p style='background: #f9f9f9; padding: 15px; border-left: 4px solid #007bff;'>
                    " . nl2br(htmlspecialchars($message)) . "
                </p>
            </div>
        ";
        
        if ($m->send()) {
            temp('info', "Your message has been sent successfully!");
            redirect('contact_admin.php');
        } else {
            temp('err', 'Failed to send email. Please try again later.');
        }
    }
}

$_title = 'Contact Admin';
require '../_head.php'; 
?>

<main style="max-width: 600px; margin: 40px auto; padding: 20px; background: rgba(128,128,128,0.05); border: 1px solid rgba(128,128,128,0.2); border-radius: 8px;">
    
    <h2 style="color: inherit; margin-top: 0;">Contact Administrator</h2>
    <p style="font-size: 16px; color: inherit; margin-bottom: 20px;">
        Have a question? Send a message directly to our administrator.
    </p>

    <hr style="margin: 20px 0; border: 0; border-top: 1px solid rgba(128,128,128,0.2);">

    <form action="" method="POST">
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: inherit;">Your Name</label>
            <?php $default_name = $_user->name ?? ''; ?>
            <input type="text" name="sender_name" value="<?= encode($default_name) ?>" placeholder="Enter your name" style="width: 100%; padding: 10px; border: 1px solid rgba(128,128,128,0.4); border-radius: 4px; background: transparent; color: inherit; box-sizing: border-box;">
            <div style="color: #ff6b6b; font-size: 13px; margin-top: 5px;"><?= err('sender_name') ?></div>
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: inherit;">Subject</label>
            <?= html_text('subject', 'placeholder="What is this regarding?" style="width: 100%; padding: 10px; border: 1px solid rgba(128,128,128,0.4); border-radius: 4px; background: transparent; color: inherit; box-sizing: border-box;"') ?>
            <div style="color: #ff6b6b; font-size: 13px; margin-top: 5px;"><?= err('subject') ?></div>
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: inherit;">Your Message</label>
            <textarea name="message" rows="6" placeholder="Type your message here..." style="width: 100%; padding: 10px; border: 1px solid rgba(128,128,128,0.4); border-radius: 4px; background: transparent; color: inherit; box-sizing: border-box;"></textarea>
            <div style="color: #ff6b6b; font-size: 13px; margin-top: 5px;"><?= err('message') ?></div>
        </div>

        <button type="submit" style="width: 100%; padding: 12px; background-color: #007bff; color: white; border: none; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer;">
            Send Message
        </button>
    </form>
    
</main>

<?php require '../_foot.php'; ?>