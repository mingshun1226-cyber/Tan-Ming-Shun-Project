<?php

require '../_base.php';

$id = get('id');


$stm = $_db->prepare("SELECT * FROM products WHERE product_id = ?");
$stm->execute([$id]);
$p = $stm->fetch();


if (!$p) {
    redirect('list.php');
}


if ($delete_review_id = get('delete_review')) {
    $current_user = $_SESSION['user_id'] ?? 'Guest';
    
    // The "AND user_id = ?" ensures users can ONLY delete their own reviews, not others!
    $stm = $_db->prepare("DELETE FROM reviews WHERE review_id = ? AND user_id = ?");
    $stm->execute([$delete_review_id, $current_user]);
    
    temp('info', 'Your review has been deleted.');
    redirect("detail.php?id=$id"); 
}

if (is_post()) {
    $action = post('action'); 

    // --- FORM 1: ADD TO CART ---
    if ($action == 'add_cart') {
        $unit = post('unit'); 
        $cart = get_cart();
        $existing_qty = $cart[$id] ?? 0; 
        update_cart($id, $existing_qty + $unit);
        redirect('/order/cart.php'); 
    }
    
    // --- FORM 2: ADD REVIEW ---
    else if ($action == 'add_review') {
        $user_id = $_SESSION['user_id'] ?? 'Guest'; 
        $rating = post('rating');
        $comment = post('comment');

        if (!$rating) {
            temp('err', 'Please select a rating.');
        } else {
            $stm = $_db->prepare("INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)");
            $stm->execute([$id, $user_id, $rating, $comment]);
            temp('info', 'Thank you for your review!');
            redirect("detail.php?id=$id"); 
        }
    }
}


$stm = $_db->prepare("SELECT * FROM reviews WHERE product_id = ? ORDER BY created_at DESC");
$stm->execute([$id]);
$reviews = $stm->fetchAll();


$_title = $p->product_name . ' - Detail';
require '../_head.php';
?>

<main style="max-width: 900px; margin: 0 auto; padding: 20px;">
    <a href="list.php" style="display: inline-block; margin-bottom: 20px; text-decoration: none; color: #007bff;">&larr; Back to Product List</a>

    <div style="display: flex; gap: 40px; align-items: flex-start; flex-wrap: wrap;">
        <div style="flex: 1; min-width: 300px;">
            <img src="../image/product_photos/<?= encode($p->photo) ?>" alt="<?= encode($p->product_name) ?>" style="width: 100%; max-width: 400px; border-radius: 8px; border: 1px solid rgba(128,128,128,0.2);">
        </div>

        <div style="flex: 2; min-width: 300px;">
            <h1 style="color: inherit;"><?= encode($p->product_name) ?></h1>
            <h2 style="color: #e44d26;">RM <?= number_format($p->price, 2) ?></h2>
            <p><strong>Stock Available:</strong> <?= encode($p->stock) ?> units</p>
            <p><strong>Description:</strong><br> <?= nl2br(encode($p->description)) ?></p>

            <hr style="margin: 20px 0; border-color: rgba(128,128,128,0.2);">

            <form action="" method="POST" style="background: rgba(128,128,128,0.05); padding: 15px; border-radius: 8px; border: 1px solid rgba(128,128,128,0.2);">
                <input type="hidden" name="action" value="add_cart">
                
                <label for="unit" style="color: inherit;"><strong>Quantity:</strong></label>
                <?php html_select('unit', $_units, null, 'style="padding: 5px; margin-left: 10px; background: transparent; color: inherit; border: 1px solid rgba(128,128,128,0.4);"'); ?>
                
                <button type="submit" style="margin-left: 10px; padding: 6px 15px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Add to Cart
                </button>
            </form>
        </div>
    </div>

    <hr style="margin: 40px 0; border: 0; border-top: 1px solid rgba(128,128,128,0.2);">
    
    <div style="display: flex; gap: 40px; flex-wrap: wrap;">
        
        <div style="flex: 2; min-width: 300px;">
            <h3 style="color: inherit;">Customer Reviews (<?= count($reviews) ?>)</h3>
            
            <?php if (empty($reviews)): ?>
                <p style="opacity: 0.7;">No reviews yet. Be the first to review this product!</p>
            <?php else: ?>
                <?php foreach ($reviews as $r): ?>
                    <div style="border-bottom: 1px solid rgba(128,128,128,0.2); padding: 15px 0;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                            <strong style="color: inherit;">👤 User <?= encode($r->user_id) ?></strong>
                            <span style="color: #f1c40f; font-size: 18px;"> 
                                <?= str_repeat('★', $r->rating) ?><span style="opacity: 0.3;"><?= str_repeat('★', 5 - $r->rating) ?></span>
                            </span>
                        </div>
                        
                        <p style="margin: 5px 0; color: inherit;"><?= nl2br(encode($r->comment)) ?></p>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
                            <small style="opacity: 0.6;"><?= date('d M Y, h:i A', strtotime($r->created_at)) ?></small>
                            
                            <?php 
                            $current_user = $_SESSION['user_id'] ?? 'Guest';
                            if ($current_user === $r->user_id): 
                            ?>
                                <a href="?id=<?= $id ?>&delete_review=<?= $r->review_id ?>" 
                                   onclick="return confirm('Are you sure you want to delete your review?')" 
                                   style="color: #ff6b6b; font-size: 13px; text-decoration: none; font-weight: bold;">
                                   Delete My Review
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div style="flex: 1; min-width: 300px;">
            <div style="background: rgba(128,128,128,0.05); padding: 20px; border-radius: 8px; border: 1px solid rgba(128,128,128,0.2);">
                <h4 style="margin-top: 0; color: inherit;">Write a Review</h4>
                <form action="" method="POST">
                    <input type="hidden" name="action" value="add_review">
                    
                    <label style="display:block; margin-bottom: 5px; font-weight: bold; color: inherit;">Rating</label>
                    <select name="rating" required style="width: 100%; padding: 8px; margin-bottom: 15px; border: 1px solid rgba(128,128,128,0.4); border-radius: 4px; background: transparent; color: inherit;">
                        <option value="" style="color: black;">Select a rating...</option>
                        <option value="5" style="color: black;">★★★★★ - Excellent</option>
                        <option value="4" style="color: black;">★★★★☆ - Good</option>
                        <option value="3" style="color: black;">★★★☆☆ - Average</option>
                        <option value="2" style="color: black;">★★☆☆☆ - Poor</option>
                        <option value="1" style="color: black;">★☆☆☆☆ - Terrible</option>
                    </select>

                    <label style="display:block; margin-bottom: 5px; font-weight: bold; color: inherit;">Your Review</label>
                    <textarea name="comment" rows="4" style="width: 100%; padding: 8px; border: 1px solid rgba(128,128,128,0.4); border-radius: 4px; box-sizing: border-box; margin-bottom: 15px; background: transparent; color: inherit;" placeholder="What did you like or dislike?"></textarea>

                    <button type="submit" style="width: 100%; padding: 10px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">
                        Submit Review
                    </button>
                </form>
            </div>
        </div>

    </div>
</main>

<?php require '../_foot.php'; ?>




