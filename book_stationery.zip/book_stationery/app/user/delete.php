<?php
include '../_base.php';
auth();

$id = $_users->id;

// Get current user record
$stm = $_db->prepare('SELECT * FROM users WHERE id = ?');
$stm->execute([$id]);
$u = $stm->fetch();

if (is_post() && $u) {
    // Delete photo if exists
    $path = __DIR__ . '/../image/user_photos/' . $u->photo;
    if ($u->photo && file_exists($path)) {
        unlink($path);
    }

    // 1. delete token
    $stm = $_db->prepare('DELETE FROM token WHERE user_id = ?');
    $stm->execute([$id]);

    // 2. delete wishlist
    $stm = $_db->prepare('DELETE FROM wishlist WHERE user_id = ?');
    $stm->execute([$id]);

    // 3. delete reviews
    $stm = $_db->prepare('DELETE FROM reviews WHERE user_id = ?');
    $stm->execute([$id]);

    // 4. delete chat messages
    $stm = $_db->prepare('DELETE FROM chat_messages WHERE user_id = ?');
    $stm->execute([$id]);

    // 5. delete admin request rows where this user is requester
    $stm = $_db->prepare('DELETE FROM admin_request WHERE user_id = ?');
    $stm->execute([$id]);

    // 6. if this user was admin who responded before, set admin_id to null
    $stm = $_db->prepare('UPDATE admin_request SET admin_id = NULL WHERE admin_id = ?');
    $stm->execute([$id]);

    // 7. delete cart items first
    $stm = $_db->prepare('
        DELETE ci
        FROM cart_items ci
        JOIN cart c ON ci.cart_id = c.cart_id
        WHERE c.user_id = ?
    ');
    $stm->execute([$id]);

    // 8. delete cart
    $stm = $_db->prepare('DELETE FROM cart WHERE user_id = ?');
    $stm->execute([$id]);

    // 9. delete order_items first
    $stm = $_db->prepare('
        DELETE oi
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.order_id
        WHERE o.user_id = ?
    ');
    $stm->execute([$id]);

    // 10. delete orders
    $stm = $_db->prepare('DELETE FROM orders WHERE user_id = ?');
    $stm->execute([$id]);

    // 11. finally delete user
    $stm = $_db->prepare('DELETE FROM users WHERE id = ?');
    $stm->execute([$id]);

    logout('/login.php');
}

$_title = 'User | Delete Account';
include '../_head.php';
?>

<style>
    .delete-page {
        max-width: 900px;
        margin: 28px auto;
        padding: 0 20px 30px;
    }

    .delete-hero {
        background: linear-gradient(135deg, #b91c1c, #dc2626);
        color: #fff;
        border-radius: 18px;
        padding: 28px 30px;
        margin-bottom: 20px;
        box-shadow: 0 10px 24px rgba(185, 28, 28, 0.18);
    }

    .delete-hero h1 {
        margin: 0 0 8px;
        font-size: 30px;
        font-weight: 800;
    }

    .delete-hero p {
        margin: 0;
        font-size: 14px;
        opacity: 0.96;
        line-height: 1.6;
    }

    .delete-layout {
        display: grid;
        grid-template-columns: 1.1fr 0.9fr;
        gap: 20px;
        align-items: start;
    }

    .delete-card,
    .delete-info-card {
        background: #fff;
        border-radius: 18px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        border: 1px solid #e5e7eb;
        overflow: hidden;
    }

    .delete-card-header,
    .delete-info-header {
        padding: 20px 24px;
        border-bottom: 1px solid #eee;
        background: #fafafa;
    }

    .delete-card-header h2,
    .delete-info-header h3 {
        margin: 0;
        font-size: 20px;
        font-weight: 800;
        color: #111;
    }

    .delete-card-body,
    .delete-info-body {
        padding: 24px;
    }

    .warning-box {
        background: #fff5f5;
        border: 1px solid #fecaca;
        border-radius: 14px;
        padding: 16px;
        margin-bottom: 20px;
        color: #991b1b;
        line-height: 1.7;
        font-size: 14px;
    }

    .account-summary {
        display: grid;
        gap: 12px;
    }

    .summary-item {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px 15px;
    }

    .summary-item b {
        display: block;
        margin-bottom: 6px;
        color: #111;
        font-size: 14px;
    }

    .summary-item span {
        color: #555;
        font-size: 13px;
        line-height: 1.6;
        word-break: break-word;
    }

    .delete-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 26px;
    }

    .btn-delete,
    .btn-cancel {
        display: inline-block;
        text-decoration: none;
        border: none;
        border-radius: 12px;
        padding: 11px 18px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: 0.2s ease;
    }

    .btn-delete {
        background: #dc2626;
        color: #fff;
    }

    .btn-delete:hover {
        background: #b91c1c;
        transform: translateY(-1px);
    }

    .btn-cancel {
        background: #f3f4f6;
        color: #111;
    }

    .btn-cancel:hover {
        background: #e5e7eb;
        transform: translateY(-1px);
    }

    .info-list {
        display: grid;
        gap: 14px;
    }

    .info-item {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px 15px;
    }

    .info-item b {
        display: block;
        margin-bottom: 6px;
        color: #111;
        font-size: 14px;
    }

    .info-item span {
        color: #555;
        font-size: 13px;
        line-height: 1.6;
    }

    .danger-note {
        margin-top: 18px;
        padding: 14px 15px;
        border-radius: 14px;
        background: #fff1f2;
        border: 1px solid #fecdd3;
        color: #9f1239;
        font-size: 13px;
        line-height: 1.6;
    }

    [data-theme="dark"] .delete-card,
    [data-theme="dark"] .delete-info-card {
        background: #1f1f1f;
        border-color: #333;
        box-shadow: none;
    }

    [data-theme="dark"] .delete-card-header,
    [data-theme="dark"] .delete-info-header {
        background: #252525;
        border-color: #333;
    }

    [data-theme="dark"] .delete-card-header h2,
    [data-theme="dark"] .delete-info-header h3,
    [data-theme="dark"] .summary-item b,
    [data-theme="dark"] .info-item b {
        color: #f1f1f1;
    }

    [data-theme="dark"] .summary-item,
    [data-theme="dark"] .info-item {
        background: #262626;
        border-color: #383838;
    }

    [data-theme="dark"] .summary-item span,
    [data-theme="dark"] .info-item span {
        color: #bdbdbd;
    }

    [data-theme="dark"] .warning-box {
        background: #3b1f1f;
        border-color: #7f1d1d;
        color: #fecaca;
    }

    [data-theme="dark"] .btn-cancel {
        background: #2a2a2a;
        color: #f1f1f1;
    }

    [data-theme="dark"] .btn-cancel:hover {
        background: #343434;
    }

    [data-theme="dark"] .danger-note {
        background: #3a1f29;
        border-color: #6b2138;
        color: #fecdd3;
    }

    @media (max-width: 860px) {
        .delete-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 600px) {
        .delete-page {
            padding: 0 12px 24px;
        }

        .delete-hero {
            padding: 22px 20px;
        }

        .delete-hero h1 {
            font-size: 24px;
        }

        .delete-card-body,
        .delete-info-body,
        .delete-card-header,
        .delete-info-header {
            padding: 20px;
        }

        .delete-actions {
            flex-direction: column;
        }

        .btn-delete,
        .btn-cancel {
            width: 100%;
            text-align: center;
        }
    }
</style>

<div class="delete-page">
    <div class="delete-hero">
        <h1>Delete Account</h1>
        <p>
            This action will permanently remove your account and related data from the system.
            Please review the information carefully before continuing.
        </p>
    </div>

    <div class="delete-layout">
        <div class="delete-card">
            <div class="delete-card-header">
                <h2>Confirm Account Deletion</h2>
            </div>

            <div class="delete-card-body">
                <div class="warning-box">
                    <b>Warning:</b> This action cannot be undone. Your account information,
                    shopping cart, wishlist, reviews, verification tokens, and related records
                    will be removed permanently.
                </div>

                <div class="account-summary">
                    <div class="summary-item">
                        <b>User ID</b>
                        <span><?= htmlspecialchars($u->id ?? '') ?></span>
                    </div>

                    <div class="summary-item">
                        <b>Name</b>
                        <span><?= htmlspecialchars($u->name ?? '') ?></span>
                    </div>

                    <div class="summary-item">
                        <b>Email</b>
                        <span><?= htmlspecialchars($u->email ?? '') ?></span>
                    </div>

                    <div class="summary-item">
                        <b>Role</b>
                        <span><?= htmlspecialchars($u->role ?? '') ?></span>
                    </div>
                </div>

                <form method="post" onsubmit="return confirm('Are you sure you want to permanently delete your account?');">
                    <div class="delete-actions">
                        <button type="submit" class="btn-delete">Delete My Account</button>
                        <a href="profile.php" class="btn-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="delete-info-card">
            <div class="delete-info-header">
                <h3>What Will Be Removed</h3>
            </div>

            <div class="delete-info-body">
                <div class="info-list">
                    <div class="info-item">
                        <b>Account Record</b>
                        <span>Your user profile, photo, and login access will be removed.</span>
                    </div>

                    <div class="info-item">
                        <b>Shopping Data</b>
                        <span>Your cart, cart items, wishlist, and related personal shopping data will be deleted.</span>
                    </div>

                    <div class="info-item">
                        <b>System Records</b>
                        <span>Your tokens, reviews, chat messages, and related request records linked to your account will be processed.</span>
                    </div>
                </div>

                <div class="danger-note">
                    If you only want to stop using the account temporarily, it is safer to keep the account instead of deleting it permanently.
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include '../_foot.php';
?>