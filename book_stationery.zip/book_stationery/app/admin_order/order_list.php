<?php
require_once '../_base.php';

auth('admin');


$stm = $_db->query('
    SELECT o.order_id, o.user_id, o.order_date, o.total_amount, o.status, u.name AS user_name,
           (SELECT SUM(quantity) FROM order_items WHERE order_id = o.order_id) AS total_items
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    ORDER BY o.order_date DESC
');
$arr = $stm->fetchAll();

$_title = 'Admin | All Orders';
require_once '../_head.php';
?>

<style>
    .admin-container {
        max-width: 1150px; 
        margin: 0 auto;
        background: #fff;
        padding: 30px;
        border-radius: 8px;
        border: 1px solid #dfdfdf;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .table th, .table td {
        padding: 12px 15px;
        border-bottom: 1px solid #eee;
        text-align: left;
        vertical-align: middle;
    }

    .table th { 
        background-color: #f5f5f5; 
        font-size: 14px; 
        color: #333;
    }
    
    .table tr:hover {
        background-color: #f9f9f9;
    }

    .right { text-align: right !important; }
    .center { text-align: center !important; }

    .user-badge {
        background-color: #e3f2fd;
        color: #0d47a1;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }

   
    .status-badge {
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
        color: white;
        display: inline-block;
        min-width: 70px;
        text-align: center;
    }
    .status-paid { background-color: #ffc107; color: #333; } 
    .status-shipped { background-color: #17a2b8; } 
    .status-completed { background-color: #28a745; } 
    .status-cancelled { background-color: #dc3545; } 

    .btn-view {
        padding: 6px 12px;
        background: #0058a3; 
        color: white;
        border: none;
        border-radius: 4px;
        text-decoration: none;
        font-size: 13px;
        cursor: pointer;
        transition: 0.2s;
    }
    .btn-view:hover { background: #004682; }
</style>

<main class="admin-container">
    <h2>📦 Manage All Orders</h2>
    <p>Total Records: <strong><?= count($arr) ?></strong> orders found in the system.</p>

    <table class="table">
        <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Order Datetime</th>
            <th class="center">Status</th> <th class="right">Total Items</th>
            <th class="right">Total (RM)</th>
            <th class="center">Action</th>
        </tr>

        <?php foreach ($arr as $o): ?>
        <tr>
            <td><strong>#<?= encode($o->order_id) ?></strong></td>
            <td>
                <span class="user-badge"><?= encode($o->user_name ?? 'Unknown') ?></span>
                <br>
                <span style="font-size: 11px; color: #888;"><?= encode($o->user_id) ?></span>
            </td>
            <td><?= encode($o->order_date) ?></td>
            
            <td class="center">
                <?php 
                    $status = $o->status ?? 'Paid'; 
                    $badge_class = 'status-paid';
                    if ($status == 'Shipped') $badge_class = 'status-shipped';
                    if ($status == 'Completed') $badge_class = 'status-completed';
                    if ($status == 'Cancelled') $badge_class = 'status-cancelled';
                ?>
                <span class="status-badge <?= $badge_class ?>"><?= encode($status) ?></span>
            </td>

            <td class="right"><?= encode($o->total_items ?? 0) ?></td>
            <td class="right" style="font-weight:bold;">
                <?= number_format((float)$o->total_amount, 2) ?>
            </td>
            <td class="center">
                <a href="order_detail.php?id=<?= $o->order_id ?>" class="btn-view">Manage Order</a>
            </td>
        </tr>
        <?php endforeach ?>
    </table>
</main>

<?php require_once '../_foot.php'; ?>