<?php
include '../_base.php';

// ----------------------------------------------------------------------------

if (is_post()) {
    $email    = req('email');
    $password = req('password');
    $confirm  = req('confirm');
    $name     = req('name');
    $role     = req('role');
    $f        = get_file('photo');

    // Validate: email
    if (!$email) {
        $_err['email'] = 'Required';
    }
    else if (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    }
    else if (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    }
    else if (!is_unique($email, 'users', 'email')) {
        $_err['email'] = 'Duplicated';
    }

    // Validate: password
    if (!$password) {
        $_err['password'] = 'Required';
    }
    else if (strlen($password) < 5 || strlen($password) > 100) {
        $_err['password'] = 'Between 5-100 characters';
    }

    // Validate: confirm
    if (!$confirm) {
        $_err['confirm'] = 'Required';
    }
    else if (strlen($confirm) < 5 || strlen($confirm) > 100) {
        $_err['confirm'] = 'Between 5-100 characters';
    }
    else if ($confirm != $password) {
        $_err['confirm'] = 'Not matched';
    }

    // Validate: name
    if (!$name) {
        $_err['name'] = 'Required';
    }
    else if (strlen($name) > 100) {
        $_err['name'] = 'Maximum 100 characters';
    }

    // Validate: role
    if ($role == '') {
        $_err['role'] = 'Required';
    }
    else if (!in_array($role, ['member', 'admin'])) {
        $_err['role'] = 'Invalid role';
    }

    // Validate: photo
    if (!$f) {
        $_err['photo'] = 'Required';
    }
    else if (!str_starts_with($f->type, 'image/')) {
        $_err['photo'] = 'Must be image';
    }
    else if ($f->size > 1 * 1024 * 1024) {
        $_err['photo'] = 'Maximum 1MB';
    }

    // DB operation
    if (!$_err) {

        // Save photo
        $photo = save_photo($f, USER_PHOTO_PATH);

        // Check how many admins exist
        $stm = $_db->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        $stm->execute();
        $admin_count = $stm->fetchColumn();

        // Default actual role
        $actual_role = 'member';

        // If selected admin and no admin exists yet
        if ($role == 'admin' && $admin_count == 0) {
            $actual_role = 'admin';
        }

        // Insert user first
        $stm = $_db->prepare('
            INSERT INTO users (id, email, password, name, photo, role)
            VALUES (?, ?, SHA1(?), ?, ?, ?)
        ');

        // ID
        $user_id = generate_id('ADM');

        $stm->execute([$user_id, $email, $password, $name, $photo, $actual_role]);

        // If selected admin and there is already at least one admin
        if ($role == 'admin' && $admin_count > 0) {

            $request_id = sha1(uniqid() . rand());

            $stm = $_db->prepare('
                INSERT INTO admin_request (id, user_id, status)
                VALUES (?, ?, ?)
            ');
            $stm->execute([$request_id, $user_id, 'pending']);

            temp('info', 'We had received your request, kindly wait for us to approve your request, thanks for your patient.');
            redirect('/login.php');
        }

        // If this is the first admin
        if ($role == 'admin' && $admin_count == 0) {
            temp('info', 'No admin exists yet. You have been registered as the first admin.');
            redirect('/login.php');
        }

        // Normal member registration
        temp('info', 'Registration successful. You can login now.');
        redirect('/login.php');
    }
}

// ----------------------------------------------------------------------------

$_title = 'User | Register Member';
include '../_head.php';
?>

<style>
.register-wrapper {
    max-width: 560px;
    margin: 40px auto 60px auto;
}

.register-card {
    background: #fff;
    border: 1px solid #e5e5e5;
    border-radius: 16px;
    padding: 30px 28px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
}

.register-card h2 {
    margin: 0 0 8px 0;
    font-size: 28px;
    color: #111;
}

.register-card p {
    margin: 0 0 24px 0;
    color: #666;
    font-size: 14px;
}

.register-form-row {
    margin-bottom: 18px;
}

.register-form-row label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #222;
}

.register-form-row input,
.register-form-row select {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 15px;
    box-sizing: border-box;
    background: #fff;
}

.register-form-row input:focus,
.register-form-row select:focus {
    outline: none;
    border-color: #0058a3;
    box-shadow: 0 0 0 3px rgba(0, 88, 163, 0.10);
}

.register-upload-box {
    border: 2px dashed #cfcfcf;
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    background: #fafafa;
    cursor: pointer;
    transition: 0.2s;
}

.register-upload-box:hover {
    border-color: #0058a3;
    background: #f4f9ff;
}

.register-upload-box img {
    width: 110px;
    height: 110px;
    object-fit: cover;
    border-radius: 10px;
    display: block;
    margin: 0 auto 10px auto;
    border: 1px solid #ddd;
}

.register-upload-text {
    font-size: 13px;
    color: #666;
}

.register-actions {
    display: flex;
    gap: 10px;
    margin-top: 14px;
}

.register-btn {
    border: none;
    border-radius: 8px;
    padding: 12px 18px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
}

.register-btn-primary {
    background: #0058a3;
    color: #fff;
}

.register-btn-primary:hover {
    background: #00457d;
}

.register-btn-secondary {
    background: #f3f3f3;
    color: #222;
    border: 1px solid #ddd;
}

.register-btn-secondary:hover {
    background: #e9e9e9;
}

.register-links {
    margin-top: 18px;
    font-size: 14px;
}

.register-links a {
    color: #0058a3;
    text-decoration: none;
    font-weight: 600;
}

.register-links a:hover {
    text-decoration: underline;
}

.err {
    display: block;
    margin-top: 6px;
    color: #d93025;
    font-size: 13px;
}

[data-theme="dark"] .register-card {
    background: #1f1f1f;
    border-color: #333;
    box-shadow: none;
}

[data-theme="dark"] .register-card h2 {
    color: #f5f5f5;
}

[data-theme="dark"] .register-card p,
[data-theme="dark"] .register-form-row label,
[data-theme="dark"] .register-upload-text {
    color: #ddd;
}

[data-theme="dark"] .register-form-row input,
[data-theme="dark"] .register-form-row select {
    background: #2a2a2a;
    border-color: #444;
    color: #fff;
}

[data-theme="dark"] .register-upload-box {
    background: #252525;
    border-color: #444;
}

[data-theme="dark"] .register-btn-secondary {
    background: #2a2a2a;
    color: #eee;
    border-color: #444;
}
</style>

<div class="register-wrapper">
    <div class="register-card">
        <h2>Create Account</h2>
        <p>Register your Books & Stationery account below.</p>

        <form method="post" enctype="multipart/form-data">
            <div class="register-form-row">
                <label for="email">Email</label>
                <?= html_text('email', 'maxlength="100" placeholder="Enter your email"') ?>
                <?= err('email') ?>
            </div>

            <div class="register-form-row">
                <label for="password">Password</label>
                <?= html_password('password', 'maxlength="100" placeholder="Enter your password"') ?>
                <?= err('password') ?>
            </div>

            <div class="register-form-row">
                <label for="confirm">Confirm Password</label>
                <?= html_password('confirm', 'maxlength="100" placeholder="Re-enter your password"') ?>
                <?= err('confirm') ?>
            </div>

            <div class="register-form-row">
                <label for="name">Full Name</label>
                <?= html_text('name', 'maxlength="100" placeholder="Enter your full name"') ?>
                <?= err('name') ?>
            </div>

            <div class="register-form-row">
                <label for="role">Account Type</label>
                <?php html_select('role', [
                    'member' => 'Member',
                    'admin'  => 'Admin Request'
                ], '- Select Role -') ?>
                <?= err('role') ?>
            </div>

            <div class="register-form-row">
                <label for="photo">Profile Photo</label>
                <label class="register-upload-box" tabindex="0">
                    <?= html_file('photo', 'image/*', 'hidden') ?>
                    <img src="/images/user_photos" alt="Preview">
                    <div class="register-upload-text">Click to upload your profile photo (max 1MB)</div>
                </label>
                <?= err('photo') ?>
            </div>

            <div class="register-actions">
                <button class="register-btn register-btn-primary">Submit</button>
                <button type="reset" class="register-btn register-btn-secondary">Reset</button>
            </div>

            <div class="register-links">
                <span>Already have an account? </span>
                <a href="/login.php">Login now</a>
            </div>
        </form>
    </div>
</div>

<?php
include '../_foot.php';
?>