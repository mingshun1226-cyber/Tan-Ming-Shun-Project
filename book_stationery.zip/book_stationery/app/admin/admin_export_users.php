<?php
require '../_base.php';
auth('admin'); 

// Set headers to force download as a CSV file
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=users_report.csv');

// Create a file pointer connected to the output stream
$output = fopen('php://output', 'w');

// Output the column headings
fputcsv($output, ['ID', 'Name', 'Email', 'Role']);

// Fetch users from database
$stm = $_db->query("SELECT id, name, email, role FROM users ORDER BY id ASC");
$users = $stm->fetchAll(PDO::FETCH_ASSOC);

// Loop over the rows, outputting them directly to the CSV
foreach ($users as $row) {
    fputcsv($output, $row);
}
fclose($output);
exit(); 