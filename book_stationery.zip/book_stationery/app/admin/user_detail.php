<?php
require '../_base.php';
auth('admin'); // Only admins can view details

$id = $_GET['id'] ?? '';

if (!$id) {
    redirect('user_list.php'); 
}

// Fetch the specific user's details
$stm = $_db->prepare("SELECT * FROM users WHERE id = ?");
$stm->execute([$id]);
$user = $stm->fetch();

if (!$user) {
    die("User not found.");
}

$_title = 'User Details';
require '../_head.php';
?>

<div style="max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
    
    <div style="text-align: center; margin-bottom: 20px;">
        <img src="/image/user_photos/<?= htmlspecialchars($user->photo ?: 'default.png') ?>" 
             style="width: 120px; height: 120px; border-radius: 50%; object-fit: cover; border: 4px solid #f0f0f0;">
        
        <h2 style="margin: 10px 0 5px;"><?= htmlspecialchars($user->name) ?></h2>
        
        <?php if ($user->role === 'admin'): ?>
            <span style="background: #ffe4e6; color: #e11d48; padding: 4px 10px; border-radius: 20px; font-weight: bold; font-size: 14px;">Admin</span>
        <?php else: ?>
            <span style="background: #dcfce7; color: #166534; padding: 4px 10px; border-radius: 20px; font-weight: bold; font-size: 14px;">Member</span>
        <?php endif; ?>
    </div>

    <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
        <table style="width: 100%; text-align: left; border-collapse: collapse;">
            <tr>
                <th style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666; width: 40%;">User ID</th>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;"><?= htmlspecialchars($user->id) ?></td>
            </tr>
            <tr>
                <th style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666;">Email Address</th>
                <td style="padding: 10px 0; border-bottom: 1px solid #eee;"><?= htmlspecialchars($user->email) ?></td>
            </tr>
        </table>
    </div>

    <div style="text-align: center;">